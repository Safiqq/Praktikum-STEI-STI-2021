/**
 * TrackableVehicle.java
 * TrackableVechile merupakan sebuah interface yang merupakan grouped interface
 * dari Vehicle dan Trackable
 * 
 * @author 18221048 Syafiq Ziyadul Arifin
 */

interface TrackableVehicle extends Vehicle, Trackable {

}