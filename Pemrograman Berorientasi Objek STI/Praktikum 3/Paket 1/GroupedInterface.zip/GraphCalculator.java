/**
 * GraphCalculator.java
 * GraphCalculator adalah sebuah interface yang merupakan grouped interface dari
 * Calculator dan GraphUpgrade
 * 
 * @author 18221048 Syafiq Ziyadul Arifin
 */

interface GraphCalculator extends Calculator, GraphUpgrade {

}